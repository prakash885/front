export interface post{
    flight_Id:string,
    airline_Id:string,
    from_location:string,
    to_location:string,
    total_seats:string

}